Year=int(input("Enter the number:"))
if(Year%4==0):
  print("The given number is Leap Year")
else:
  print("The given number is not Leap year")